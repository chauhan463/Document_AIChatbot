# data_gen.py
import numpy as np
from math import pi

def generate_synthetic(num_nodes=4, seq_len=2000, sensors=4, seed=0):
    """
    Generate synthetic multivariate time-series data.
    Output shape: (T, N, F)
    """
    np.random.seed(seed)
    t = np.arange(seq_len)
    data = np.zeros((seq_len, num_nodes, sensors), dtype=np.float32)
    freqs = [0.005, 0.003, 0.001, 0.002]
    amps = [1.0, 0.6, 0.8, 0.5]
    noise_std = [0.02, 0.01, 0.02, 0.01]
    for n in range(num_nodes):
        for s in range(sensors):
            phase = np.random.uniform(0, 2*pi)
            data[:, n, s] = amps[s] * np.sin(2*pi*freqs[s]*t + phase) + noise_std[s]*np.random.randn(seq_len)
    # Introduce a slow drift fault on node0 vibration
    drift = np.zeros(seq_len, dtype=np.float32)
    drift[800:1200] = np.linspace(0, 2.0, 400)
    data[:, 0, 0] += drift
    # Propagate effect to node1 vibration with delay and attenuation
    data[900:1300, 1, 0] += 0.6 * np.linspace(0, 2.0, 400)
    # Inject short anomalies
    data[1500:1510, 2, 2] += 3.0  # power spike on node2
    data[1600:1620, 3, 1] += 2.0  # temp rise on node3
    return data

def create_sequences(data, window=64, step=1):
    """
    Convert raw data (T x N x F) into sliding windows.
    Returns X: B x W x N x F and Y: B x N x F (next timestep target)
    """
    T, N, F = data.shape
    X = []
    Y = []
    for i in range(0, T - window - 1, step):
        X.append(data[i:i+window])
        Y.append(data[i+window])
    X = np.stack(X)
    Y = np.stack(Y)
    return X, Y


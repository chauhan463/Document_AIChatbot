# utils.py
import torch
from torch.utils.data import Dataset

class SensorSequenceDataset(Dataset):
    """
    Wrap numpy X, Y arrays into a PyTorch Dataset.
    X: B x W x N x F
    Y: B x N x F
    """
    def __init__(self, X, Y):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.Y = torch.tensor(Y, dtype=torch.float32)

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, idx):
        return self.X[idx], self.Y[idx]


# model.py
import torch
import torch.nn as nn
import numpy as np

class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=512):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-np.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe.unsqueeze(0))  # 1 x max_len x d_model

    def forward(self, x):
        # x: B x W x D
        w = x.shape[1]
        return x + self.pe[:, :w].to(x.device)

class SimpleTGT(nn.Module):
    """
    Compact Temporal Graph Transformer style model:
    - per-node temporal transformer encoder
    - graph aggregation via normalized adjacency
    - reconstruction and 1-step forecast heads
    """
    def __init__(self, feat_dim=4, model_dim=64, num_heads=4, num_layers=2, num_nodes=4, adj=None):
        super().__init__()
        self.feat_dim = feat_dim
        self.model_dim = model_dim
        self.num_nodes = num_nodes

        self.input_proj = nn.Linear(feat_dim, model_dim)
        self.pos_enc = PositionalEncoding(model_dim, max_len=512)
        encoder_layer = nn.TransformerEncoderLayer(d_model=model_dim, nhead=num_heads, dim_feedforward=128)
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)

        if adj is None:
            adj = torch.eye(num_nodes)
        self.register_buffer('adj', torch.tensor(adj, dtype=torch.float32))

        self.graph_lin = nn.Linear(model_dim, model_dim)
        self.recon_head = nn.Sequential(nn.Linear(model_dim, 64), nn.ReLU(), nn.Linear(64, feat_dim))
        self.forecast_head = nn.Sequential(nn.Linear(model_dim, 64), nn.ReLU(), nn.Linear(64, feat_dim))

    def forward(self, x):
        # x: B x W x N x F
        B, W, N, F = x.shape
        assert N == self.num_nodes and F == self.feat_dim
        # project per feature
        x_flat = x.view(B*W*N, F)
        h = self.input_proj(x_flat)  # (B*W*N) x D
        h = h.view(B, W, N, self.model_dim)  # B x W x N x D

        # transformer per node
        h_nodes = h.permute(0,2,1,3).contiguous()  # B x N x W x D
        h_nodes = h_nodes.view(B*N, W, self.model_dim)  # (B*N) x W x D
        h_nodes = self.pos_enc(h_nodes)
        # Transformer expects (W, batch, D)
        h_t = self.transformer(h_nodes.transpose(0,1)).transpose(0,1)  # (B*N) x W x D
        h_last = h_t[:, -1, :].view(B, N, self.model_dim)  # B x N x D

        # normalize adjacency row-wise
        adj = self.adj
        deg = adj.sum(dim=1, keepdim=True)
        deg[deg == 0] = 1.0
        A_norm = adj / deg
        A_batch = A_norm.unsqueeze(0).expand(B, -1, -1)  # B x N x N

        neigh = torch.matmul(A_batch, h_last)  # B x N x D
        h_graph = self.graph_lin(neigh)  # B x N x D

        recon = self.recon_head(h_graph)      # B x N x F
        forecast = self.forecast_head(h_graph)  # B x N x F
        return recon, forecast, h_graph


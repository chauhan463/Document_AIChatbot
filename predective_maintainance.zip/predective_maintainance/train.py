# train.py
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

from data_gen import generate_synthetic, create_sequences
from model import SimpleTGT
from utils import SensorSequenceDataset

def main():
    # --- config
    num_nodes = 4
    feat_dim = 4
    seq_len = 2000
    window = 64
    step = 4
    batch_size = 32
    epochs = 12
    lr = 1e-3
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # --- data
    data = generate_synthetic(num_nodes=num_nodes, seq_len=seq_len, sensors=feat_dim, seed=1)
    X, Y = create_sequences(data, window=window, step=step)
    # train/test split (time-based)
    train_split = int(0.7 * len(X))
    X_train, Y_train = X[:train_split], Y[:train_split]
    X_test, Y_test = X[train_split:], Y[train_split:]
    train_ds = SensorSequenceDataset(X_train, Y_train)
    test_ds = SensorSequenceDataset(X_test, Y_test)
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_ds, batch_size=64, shuffle=False)

    # adjacency matrix (example physical adjacency)
    adj = np.array([
        [1.0, 0.8, 0.0, 0.0],
        [0.8, 1.0, 0.2, 0.0],
        [0.0, 0.2, 1.0, 0.3],
        [0.0, 0.0, 0.3, 1.0],
    ], dtype=np.float32)

    # --- model
    model = SimpleTGT(feat_dim=feat_dim, model_dim=64, num_heads=4, num_layers=2, num_nodes=num_nodes, adj=adj).to(device)
    opt = optim.Adam(model.parameters(), lr=lr)
    criterion = nn.MSELoss()

    train_losses = []
    test_losses = []

    for epoch in range(epochs):
        model.train()
        running = 0.0
        for xb, yb in train_loader:
            xb = xb.to(device)
            yb = yb.to(device)
            opt.zero_grad()
            recon, forecast, _ = model(xb)
            loss = criterion(recon, xb[:, -1]) + criterion(forecast, yb)
            loss.backward()
            opt.step()
            running += loss.item() * xb.size(0)
        epoch_loss = running / len(train_loader.dataset)
        train_losses.append(epoch_loss)

        model.eval()
        running_t = 0.0
        with torch.no_grad():
            for xb, yb in test_loader:
                xb = xb.to(device)
                yb = yb.to(device)
                recon, forecast, _ = model(xb)
                loss_t = criterion(recon, xb[:, -1]) + criterion(forecast, yb)
                running_t += loss_t.item() * xb.size(0)
            test_epoch_loss = running_t / len(test_loader.dataset)
            test_losses.append(test_epoch_loss)
        print(f"Epoch {epoch+1:02d} TrainLoss: {epoch_loss:.6f} TestLoss: {test_epoch_loss:.6f}")

    # --- inference + anomaly scoring on test set
    model.eval()
    all_scores = []
    window_starts = np.arange(0, data.shape[0] - window - 1, step)
    test_window_starts = window_starts[train_split:]
    window_end_times = test_window_starts + window

    with torch.no_grad():
        for xb, yb in test_loader:
            xb = xb.to(device); yb = yb.to(device)
            recon, forecast, _ = model(xb)
            rec_err = torch.mean((recon - xb[:, -1])**2, dim=-1)  # B x N
            f_err = torch.mean((forecast - yb)**2, dim=-1)       # B x N
            score = (rec_err + f_err).cpu().numpy()
            all_scores.append(score)
    scores = np.concatenate(all_scores, axis=0)  # M x N

    # Build labels for injected anomalies (same mapping as generator)
    labels = np.zeros((len(window_end_times), num_nodes), dtype=int)
    for i, tval in enumerate(window_end_times):
        if 1500 <= tval < 1510:
            labels[i, 2] = 1
        if 1600 <= tval < 1620:
            labels[i, 3] = 1

    # Plot node-wise scores around injected events
    try:
        import matplotlib.pyplot as plt
        for node in [2,3]:
            plt.figure()
            plt.plot(window_end_times, scores[:, node])
            plt.title(f'Anomaly Score (node {node})')
            plt.xlabel('time index')
            plt.ylabel('score')
            plt.grid(True)
            plt.show()
    except Exception:
        pass

    # Simple threshold detection summary
    summary = {}
    for n in range(num_nodes):
        thr = scores[:, n].mean() + 3 * scores[:, n].std()
        detections = (scores[:, n] > thr).astype(int)
        tp = int(((detections == 1) & (labels[:, n] == 1)).sum())
        fp = int(((detections == 1) & (labels[:, n] == 0)).sum())
        fn = int(((detections == 0) & (labels[:, n] == 1)).sum())
        summary[f'node{n}'] = {'tp': tp, 'fp': fp, 'fn': fn, 'threshold': float(thr)}
    print("Detection summary (threshold = mean+3*std):")
    for k,v in summary.items():
        print(k, v)

    # show a small table near events
    near_mask = (window_end_times >= 1490) & (window_end_times <= 1625)
    df = pd.DataFrame(scores[near_mask], columns=[f'node{i}' for i in range(num_nodes)])
    df['time'] = window_end_times[near_mask]
    cols = ['time'] + [f'node{i}' for i in range(num_nodes)]
    print("\nScores near injected events:")
    print(df[cols].head(20))

if __name__ == "__main__":
    main()

